package enums;

public enum OperationEnum {
    SUM, /*(SUM(Integer v1, Integer v2) -> v1 + v2)*/
    SUBTRACT, /*(SUBTRACT(Integer v1, Integer v2) -> v1 - v2)*/
    MULTIPLY, /*(MULTIPLY(Integer v1, Integer v2) -> v1 * v2)*/
    DIVIDE /*(DIVIDE(Integer v1, Integer v2) -> v1 / v2)*/
}
