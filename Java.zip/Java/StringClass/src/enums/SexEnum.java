package enums;

public enum SexEnum {
    MALE,
    FEMALE
}
