import static enums.SexEnum.MALE;
import static enums.SexEnum.FEMALE;

import java.math.BigDecimal;
import java.util.Optional;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //String

        //StringBuilder e StringBuffer
        StringBuilder strBuilder = new StringBuilder(); /*Singlethread*/
        strBuilder.append("Hello World");
        strBuilder.append("!!!");
        strBuilder.append("\n");
        strBuilder.append("Welcome to Java Programming.");
        strBuilder.append("\n");
        System.out.println(strBuilder.toString());

        System.out.println("-----");

        StringBuffer strBuffer = new StringBuffer(); /*Multitread*/
        strBuffer.append("Hello World");
        strBuffer.append("!!!");
        strBuffer.append("\n");
        strBuffer.append("Welcome to Java Programming.");
        strBuffer.append("\n");
        System.out.println(strBuffer.toString());

        System.out.println("-----BigDecimal-----");

        BigDecimal bg = new BigDecimal("100");
        bg = bg.add(new BigDecimal("0.50"));
        System.out.println(bg);
        bg = bg.subtract(new BigDecimal("0.10"));
        System.out.println(bg);
        bg = bg.divide(new BigDecimal("0.10"));
        System.out.println(bg);
        bg = bg.multiply(BigDecimal.TEN);
        System.out.printf("%,.2f%n", bg);

        System.out.println("-----Enums-----");

        var operation = enums.OperationEnum.SUM;
        switch (operation) {
            case SUM:
                System.out.println("Operation: SUM");
                break;
            case SUBTRACT:
                System.out.println("Operation: SUBTRACT");
                break;
            case MULTIPLY:
                System.out.println("Operation: MULTIPLY");
                break;
            case DIVIDE:
                System.out.println("Operation: DIVIDE");
                break;
        }

        System.out.println("-----Optional-----");
        Optional<User> optional = Optional.of(new User("John Doe", 30, MALE));
        System.out.println(optional.isEmpty());
        System.out.println(optional.isPresent());
        System.out.println(optional.get());

        System.out.println("-----nullable-----");
        Optional<User> optional2 = Optional.ofNullable(null);
        System.out.println(optional2.isEmpty());
        System.out.println(optional2.isPresent());
        System.out.println(optional2.orElse(new User("Default User", 0, MALE)));

        System.out.println("-----ifPresentOrElse----- NULL case");
        optional2.ifPresentOrElse(user -> System.out.println("User found: " + user),
                () -> System.out.println("No user found."));

        System.out.println("-----ifPresentOrElse-----");
        optional2.ifPresentOrElse(
                user -> {
                        System.out.println("User found: " + user);
                        user = new User("Jane Doe", 25, FEMALE);
                        System.out.println("Updated User: " + user);
                    },
                    () -> System.out.println("No user found."));

        System.out.println("-----ifPresentOrElse----- User found.");
        optional2 = Optional.of(new User("Alice Smith", 28, FEMALE));
        optional2.ifPresentOrElse(
                user -> {
                    System.out.println("User found: " + user);
                    user = new User("Jane Doe", 25, FEMALE);
                    System.out.println("Updated User: " + user);
                },
                () -> System.out.println("No user found."));

        System.out.println("-----RunTimeException-----");
        System.out.println(optional2.orElseThrow(() -> new RuntimeException("User not found!")));
    }
}