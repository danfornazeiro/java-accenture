import enums.SexEnum;

public record User(String name, int age, SexEnum sex) {}
