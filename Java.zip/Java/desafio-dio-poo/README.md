# Desafio DIO - POO em Java

## 📋 Descrição
Este projeto é um desafio desenvolvido durante o curso de Java da Digital Innovation One (DIO), com foco em conceitos de Programação Orientada a Objetos (POO). O código principal está localizado em `src/Main.java` e serve como ponto de partida para implementar as funcionalidades do desafio.

## 🛠️ Tecnologias Utilizadas
- **Java**: Linguagem de programação principal.
- **IntelliJ IDEA**: IDE recomendada para desenvolvimento.

## 🚀 Como Executar
1. Certifique-se de ter o Java JDK instalado em sua máquina.
2. Clone este repositório ou baixe os arquivos.
3. Abra o projeto no IntelliJ IDEA (ou outra IDE compatível com Java).
4. Execute a classe `Main` localizada em `src/Main.java`.

## 📁 Estrutura do Projeto
```
desafio-dio-poo/
├── src/
│   └── Main.java
├── desafio-dio-poo.iml
└── README.md
```

## 📚 Aprendizados
Durante este desafio, foram aplicados conceitos fundamentais de POO, como:
- Classes e Objetos
- Abstração
- Encapsulamento
- Herança
- Polimorfismo

## 🤝 Contribuição
Sinta-se à vontade para contribuir com melhorias ou correções. Abra uma issue ou envie um pull request!

## 📄 Licença
Este projeto é para fins educacionais e faz parte do curso da DIO.
