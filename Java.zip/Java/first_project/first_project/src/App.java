public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        System.out.println("Configurando a JDK na versao: " + args[0]);
        System.out.println("Configurando em: " + args[1]);
    }
}
