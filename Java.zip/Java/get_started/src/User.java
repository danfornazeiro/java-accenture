public record User(String name, int age) {}
