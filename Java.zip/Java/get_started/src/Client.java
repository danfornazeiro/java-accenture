/*não pode eestender Salesmasn por causa do final.*/

public class Client{
    private String document;

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }
}
