public interface VideoPlayer
{
    void playVideo();
    void pauseVideo();
    void stopVideo();
}
