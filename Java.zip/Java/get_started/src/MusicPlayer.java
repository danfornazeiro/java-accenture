public interface MusicPlayer {
    void playMusic();
    void pauseMusic();
    void stopMusic();
}
