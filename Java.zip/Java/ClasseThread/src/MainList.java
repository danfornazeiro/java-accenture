import java.util.ArrayList;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class MainList {
    private final static List<Integer> numbers = new ArrayList<>();

    private synchronized static void inc(int number) {
        numbers.add(number);
    }

    private synchronized static void show() {
        System.out.println(numbers);
    }

    public static void main(String[] args) {
        Runnable inc = () -> {
            for (int i = 0; i < 100_000; i++) {
                inc(i);
            }
        };

        Runnable dec = () -> {
            for (int i = 100_000; i > 0; i--) {
                inc(i);
            }
        };

        Runnable show = () -> {
            for (int i = 0; i < 250_000; i++) {
                show();
            }
        };

        new Thread(inc).start();
        new Thread(dec).start();
        new Thread(show).start();
    }
}