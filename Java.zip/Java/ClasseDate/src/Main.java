import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        var strDate = "13/01/2026";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println(formatter.format(localDate.parse(strDate, formatter)));

        System.out.println(localDate.plus(50, ChronoUnit.DAYS));
        System.out.println(localDate.plusDays(1));
        System.out.println(localDate.minusWeeks(2));
        System.out.println(localDate.minusDays(1));

        LocalTime localTime = LocalTime.now();
        System.out.println(localTime);
        System.out.println(localTime.plusHours(2).plusMinutes(30));

        LocalDateTime localDateTime = localDate.atTime(localTime);
        System.out.println(localDateTime);

        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        LocalDateTime localDateTime1 =  LocalDateTime.ofInstant(date.toInstant(), calendar.getTimeZone().toZoneId());
        System.out.println(localDateTime1);

        System.out.println(Duration.between(localDateTime, LocalDateTime.now()).toMillis());

        OffsetDateTime offSetDateTime = OffsetDateTime.now();
        offSetDateTime = offSetDateTime.withOffsetSameInstant(ZoneOffset.UTC);

        System.out.println(offSetDateTime.getOffset());
        System.out.println(offSetDateTime.getDayOfYear());


    }
}
