import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainDate {

    public static void main(String[] args) {
        var date = new Date();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy - hh:mm:ss");
        System.out.println(date);
        System.out.println(formatter.format(new Date()));

        var date2 = new Date(System.currentTimeMillis()-9999999999L);
        System.out.println(date2);

        var date3 = new Date();
        date3.setHours(22);
        System.out.println(date3);

        var milliseconds = System.currentTimeMillis();
        var date4 = new Date(milliseconds);
        var newDate = new Date(milliseconds);
        System.out.println(new Date(milliseconds + 9999999999L).after( date ));
        System.out.println(date.getTime());
    }
}