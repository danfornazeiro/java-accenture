package com.avanade.livraria.service;

import java.sql.Connection;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.avanade.livraria.domain.Livro;
import com.avanade.livraria.domain.TipoUsuario;
import com.avanade.livraria.domain.Usuario;
import com.avanade.livraria.repository.Database;
import com.avanade.livraria.repository.JdbcRepositorioEmprestimo;
import com.avanade.livraria.repository.JdbcRepositorioLivro;
import com.avanade.livraria.repository.JdbcRepositorioMulta;
import com.avanade.livraria.repository.JdbcRepositorioUsuario;

public class ServicoEmprestimoTest {
    private Connection conn;
    private JdbcRepositorioLivro livroRepo;
    private JdbcRepositorioUsuario usuarioRepo;
    private JdbcRepositorioEmprestimo emprestimoRepo;
    private ServicoEmprestimo servico;
    private JdbcRepositorioMulta multaRepo;

    @BeforeEach
    void setup() throws Exception {
        Database.init();
        conn = Database.getConnection();
        
        // Limpar tabelas antes de cada teste
        try (var stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM multas");
            stmt.execute("DELETE FROM loans");
            stmt.execute("DELETE FROM books");
            stmt.execute("DELETE FROM users");
        }
        
        livroRepo = new JdbcRepositorioLivro(conn);
        usuarioRepo = new JdbcRepositorioUsuario(conn);
        emprestimoRepo = new JdbcRepositorioEmprestimo(conn);
        multaRepo = new JdbcRepositorioMulta(conn);
        servico = new ServicoEmprestimo(livroRepo, usuarioRepo, emprestimoRepo, multaRepo);
    }

    @Test
    void criarEmprestimoReduzDisponiveis() {
        Livro l = new Livro("TDD", "Author", "111", 1);
        livroRepo.save(l);
        Usuario u = new Usuario("Tester", "000.000.000-00", TipoUsuario.ESTUDANTE);
        usuarioRepo.save(u);

        var emprestimo = servico.criarEmprestimo(u.getId(), l.getId());
        assertNotNull(emprestimo.getId());
        var updated = livroRepo.findById(l.getId()).orElseThrow();
        assertEquals(0, updated.getAvailableCopies());
    } 

    @Test
    void criarEmprestimoComDevolucaoDuasCopias() {
        Livro l = new Livro("TDD", "Author", "111", 2);
        livroRepo.save(l);
        Usuario u = new Usuario("Tester", "000.000.000-00", TipoUsuario.ESTUDANTE);
        usuarioRepo.save(u);

        var emprestimo = servico.criarEmprestimo(u.getId(), l.getId());
        assertNotNull(emprestimo.getId());
        var updated = livroRepo.findById(l.getId()).orElseThrow();
        assertEquals(1, updated.getAvailableCopies());
    }    
    
    @Test
    void devolucaoSemMulta() {
        Livro l = new Livro("TDD", "Author", "111", 1);
        livroRepo.save(l);
        Usuario u = new Usuario("Tester", "000.000.000-00", TipoUsuario.ESTUDANTE);
        usuarioRepo.save(u);

        var emprestimo = servico.criarEmprestimo(u.getId(), l.getId());
        servico.devolverEmprestimo(emprestimo.getId());
        var emprestimoAtualizado = emprestimoRepo.findById(emprestimo.getId()).orElseThrow();
        var multa = servico.calcularMulta(emprestimoAtualizado);
        assertNull(multa, "Nenhuma multa deve ser calculada para devolução no prazo");
    }

    @Test
    void calcularMulta() {
        Livro l = new Livro("TDD", "Author", "111", 1);
        livroRepo.save(l);
        Usuario u = new Usuario("Tester", "000.000.000-00", TipoUsuario.ESTUDANTE);
        usuarioRepo.save(u);

        var emprestimo = servico.criarEmprestimo(u.getId(), l.getId());
        emprestimo.setReturnDate(emprestimo.getDueDate().plusDays(5)); // Simula atraso de 5 dias
        var multa = servico.calcularMulta(emprestimo);
        assertNotNull(multa, "Multa deve ser calculada para devolução atrasada");
        assertEquals(5.0, multa.getValor().doubleValue(), "Multa deve ser R$1 por dia de atraso");
    }    

}