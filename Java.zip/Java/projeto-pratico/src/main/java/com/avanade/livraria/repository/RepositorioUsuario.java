package com.avanade.livraria.repository;

import com.avanade.livraria.domain.Usuario;
import java.util.Optional;

public interface RepositorioUsuario {
    Usuario save(Usuario usuario);
    Optional<Usuario> findById(Long id);
}
