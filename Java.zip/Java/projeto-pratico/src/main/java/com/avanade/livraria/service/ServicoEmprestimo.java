package com.avanade.livraria.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.avanade.livraria.domain.Emprestimo;
import com.avanade.livraria.domain.Livro;
import com.avanade.livraria.domain.Multa;
import com.avanade.livraria.domain.TipoUsuario;
import com.avanade.livraria.domain.Usuario;
import com.avanade.livraria.dto.EmprestimoDTO;
import com.avanade.livraria.repository.RepositorioEmprestimo;
import com.avanade.livraria.repository.RepositorioLivro;
import com.avanade.livraria.repository.RepositorioMulta;
import com.avanade.livraria.repository.RepositorioUsuario;

public class ServicoEmprestimo {
    private final RepositorioLivro livroRepo;
    private final RepositorioUsuario usuarioRepo;
    private final RepositorioEmprestimo emprestimoRepo;
    private final RepositorioMulta multaRepo;

    public ServicoEmprestimo(RepositorioLivro livroRepo, RepositorioUsuario usuarioRepo, RepositorioEmprestimo emprestimoRepo, RepositorioMulta multaRepo) {
        this.livroRepo = livroRepo;
        this.usuarioRepo = usuarioRepo;
        this.emprestimoRepo = emprestimoRepo;
        this.multaRepo = multaRepo;
    }

    public Emprestimo criarEmprestimo(Long usuarioId, Long livroId) {
        Optional<Usuario> ou = usuarioRepo.findById(usuarioId);
        Optional<Livro> ob = livroRepo.findById(livroId);
        if (ou.isEmpty()) throw new IllegalArgumentException("Usuario nao encontrado");
        if (ob.isEmpty()) throw new IllegalArgumentException("Livro nao encontrado");
        Usuario usuario = ou.get();
        Livro livro = ob.get();
        if (livro.getAvailableCopies() <= 0) throw new IllegalStateException("Sem copias disponiveis");

        int days = usuario.getUserType() == TipoUsuario.PROFESSOR ? 30 : 14;
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime due = now.plusDays(days);

        Emprestimo emprestimo = new Emprestimo(livro.getId(), usuario.getId(), now, due);
        Emprestimo saved = emprestimoRepo.save(emprestimo);

        livro.setAvailableCopies(livro.getAvailableCopies() - 1);
        livroRepo.update(livro);

        return saved;
    }

    public List<Emprestimo> listarEmprestimos() {
        return emprestimoRepo.findAll();
    }

    public void devolverEmprestimo(Long emprestimoId) {

        emprestimoRepo.devolverEmprestimo(emprestimoId);
        var emprestimo = emprestimoRepo.findById(emprestimoId).orElseThrow(() -> new IllegalArgumentException("Emprestimo nao encontrado"));

        Optional<Livro> ob = livroRepo.findById(emprestimo.getBookId());
        if (ob.isEmpty()) throw new IllegalStateException("Livro do emprestimo nao encontrado");
        Livro livro = ob.get();
        livro.setAvailableCopies(livro.getAvailableCopies() + 1);
        livroRepo.update(livro);
    }

    public Multa calcularMulta(Emprestimo emprestimo) {
        if (emprestimo.getReturnDate() == null) return null; // Ainda não devolvido
        if (emprestimo.getReturnDate().isBefore(emprestimo.getDueDate())) return null; // Devolvido no prazo

        long daysLate = java.time.Duration.between(emprestimo.getDueDate(), emprestimo.getReturnDate()).toDays();
        double fineAmount = daysLate * 1.0; // R$1 por dia de atraso
        var multa = multaRepo.save(new com.avanade.livraria.domain.Multa(emprestimo.getId(), BigDecimal.valueOf(fineAmount)));                

        return multa;
    }

    public List<EmprestimoDTO> listarEmprestimosAtivos() {
        return emprestimoRepo.findEmprestimosAtivos().stream()
            .map(emprestimo -> {
                Livro livro = livroRepo.findById(emprestimo.getBookId())
                    .orElseThrow(() -> new IllegalStateException("Livro nao encontrado"));
                Usuario usuario = usuarioRepo.findById(emprestimo.getUserId())
                    .orElseThrow(() -> new IllegalStateException("Usuario nao encontrado"));
                
                return new EmprestimoDTO(
                    emprestimo.getId(),
                    livro.getTitle(),
                    livro.getAuthor(),
                    usuario.getName(),
                    emprestimo.getLoanDate(),
                    emprestimo.getDueDate()
                );
            })
            .collect(Collectors.toList());
    }
}
