package com.avanade.livraria.repository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Optional;

import com.avanade.livraria.domain.Multa;

public class JdbcRepositorioMulta implements RepositorioMulta {
    private final Connection conn;

    public JdbcRepositorioMulta(Connection conn) { this.conn = conn;}
    
    @Override
    public Multa save(Multa multa) {
        String sql = "INSERT INTO multas(emprestimoId,valor,dataPagamento) VALUES (?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, multa.getEmprestimoId());
            ps.setBigDecimal(2, multa.getValor());
            if (multa.getDataPagamento() != null) ps.setTimestamp(3, Timestamp.valueOf(multa.getDataPagamento())); else ps.setTimestamp(3, null);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) multa.setId(rs.getLong(1));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return multa;
    }

    @Override
    public Optional<Multa> findById(Long id) {
        return Optional.empty();
    }

    @Override
    public Optional<Multa> findByEmprestimoId(Long emprestimoId) {
        String sql = "SELECT id,emprestimoId,valor,dataPagamento FROM multas WHERE emprestimoId = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, emprestimoId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Multa m = new Multa(rs.getLong("id"), rs.getLong("emprestimoId"), rs.getBigDecimal("valor"), rs.getTimestamp("dataPagamento") != null ? rs.getTimestamp("dataPagamento").toLocalDateTime() : null);
                    return Optional.of(m);
                }
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
