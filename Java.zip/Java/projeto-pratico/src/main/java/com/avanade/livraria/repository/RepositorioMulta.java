package com.avanade.livraria.repository;

import java.util.Optional;

import com.avanade.livraria.domain.Multa;

public interface RepositorioMulta {
    Multa save(Multa multa);
    Optional<Multa> findById(Long id);
    Optional<Multa> findByEmprestimoId(Long emprestimoId);
}
