package com.avanade.livraria.domain;

public enum TipoUsuario {
    ESTUDANTE, PROFESSOR
}
