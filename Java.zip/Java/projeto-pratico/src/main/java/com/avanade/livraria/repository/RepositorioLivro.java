package com.avanade.livraria.repository;

import com.avanade.livraria.domain.Livro;
import java.util.List;
import java.util.Optional;

public interface RepositorioLivro {
    Livro save(Livro livro);
    Optional<Livro> findById(Long id);
    List<Livro> findAll();
    void update(Livro livro);
}
