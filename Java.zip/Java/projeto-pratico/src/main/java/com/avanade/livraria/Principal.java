package com.avanade.livraria;

import java.sql.Connection;

import com.avanade.livraria.domain.Emprestimo;
import com.avanade.livraria.domain.Livro;
import com.avanade.livraria.domain.TipoUsuario;
import com.avanade.livraria.domain.Usuario;
import com.avanade.livraria.repository.Database;
import com.avanade.livraria.repository.JdbcRepositorioEmprestimo;
import com.avanade.livraria.repository.JdbcRepositorioLivro;
import com.avanade.livraria.repository.JdbcRepositorioMulta;
import com.avanade.livraria.repository.JdbcRepositorioUsuario;
import com.avanade.livraria.service.ServicoEmprestimo;

public class Principal {

    public static void main(String[] args) throws Exception {
        
        Database.init();
        try (Connection conn = Database.getConnection()) {
            JdbcRepositorioLivro livroRepo = new JdbcRepositorioLivro(conn);
            JdbcRepositorioUsuario usuarioRepo = new JdbcRepositorioUsuario(conn);
            JdbcRepositorioEmprestimo emprestimoRepo = new JdbcRepositorioEmprestimo(conn);
            JdbcRepositorioMulta multaRepo = new JdbcRepositorioMulta(conn);
            // Seed
            Livro l1 = new Livro("Clean Code", "Robert C. Martin", "978-0132350884", 3);
            Livro l2 = new Livro("Effective Java", "Joshua Bloch", "978-0134685991", 2);
            livroRepo.save(l1);
            livroRepo.save(l2);

            Usuario u1 = new Usuario("Alice", "111.111.111-11", TipoUsuario.ESTUDANTE);
            Usuario u2 = new Usuario("Professor Bob", "222.222.222-22", TipoUsuario.PROFESSOR);
            usuarioRepo.save(u1);
            usuarioRepo.save(u2);

            ServicoEmprestimo servico = new ServicoEmprestimo(livroRepo, usuarioRepo, emprestimoRepo, multaRepo);
            var emprestimo = servico.criarEmprestimo(u1.getId(), l1.getId());
            System.out.println("Emprestimo criado: id=" + emprestimo.getId() + " due=" + emprestimo.getDueDate());

            System.out.println("Livros atualmente no DB:");
            for (Livro b : livroRepo.findAll()) {
                System.out.println(b.getId() + " - " + b.getTitle() + " (available=" + b.getAvailableCopies() + ")");
            }

            System.out.println("Emprestimos atualmente no DB:");
            for (Emprestimo e : servico.listarEmprestimos()) {
                System.out.println(e.getId() + " - bookId=" + e.getBookId() + " userId=" + e.getUserId() + " due=" + e.getDueDate());
            }

            System.err.println("Devolução de livros:");
            for (Emprestimo e : emprestimoRepo.findAll()) {
                System.out.println("Devolvendo emprestimo id=" + e.getId());
                servico.devolverEmprestimo(e.getId());
                var emprestimoAtualizado = emprestimoRepo.findById(e.getId()).orElseThrow(() -> new IllegalArgumentException("Emprestimo nao encontrado"));
                var multa = servico.calcularMulta(emprestimoAtualizado);
                if (multa != null) {
                    System.out.println("Multa aplicada: R$" + multa.getValor());
                } else {    
                    System.out.println("Nenhuma multa aplicada.");
                }
            }

            System.out.println("Emprestimos devolvidos:");
            for (Emprestimo e : servico.listarEmprestimos()) {
               if (e.getReturnDate() != null) {
                   System.out.println(e.getId() + " - bookId=" + e.getBookId() + " userId=" + e.getUserId() + " due=" + e.getDueDate() + " return=" + e.getReturnDate());
               }
            }

            System.out.println("Multas registradas: ");
            var multas = multaRepo.findByEmprestimoId(emprestimo.getId());
            if (multas.isEmpty()) {
                System.out.println("Nenhuma multa encontrada para o emprestimo id=" + emprestimo.getId());
            } else {
                multas.ifPresent(m -> System.out.println("Multa id=" + m.getId() + " valor=" + m.getValor() + " dataPagamento=" + m.getDataPagamento()));
            }
            
        }
        
    }
}
