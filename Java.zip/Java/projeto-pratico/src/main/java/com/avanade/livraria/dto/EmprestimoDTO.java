package com.avanade.livraria.dto;

import java.time.LocalDateTime;

public class EmprestimoDTO {
    private Long emprestimoId;
    private String livroTitulo;
    private String livroAutor;
    private String usuarioNome;
    private LocalDateTime dataEmprestimo;
    private LocalDateTime dataVencimento;

    public EmprestimoDTO(Long emprestimoId, String livroTitulo, String livroAutor, 
                         String usuarioNome, LocalDateTime dataEmprestimo, LocalDateTime dataVencimento) {
        this.emprestimoId = emprestimoId;
        this.livroTitulo = livroTitulo;
        this.livroAutor = livroAutor;
        this.usuarioNome = usuarioNome;
        this.dataEmprestimo = dataEmprestimo;
        this.dataVencimento = dataVencimento;
    }

    public Long getEmprestimoId() { return emprestimoId; }
    public String getLivroTitulo() { return livroTitulo; }
    public String getLivroAutor() { return livroAutor; }
    public String getUsuarioNome() { return usuarioNome; }
    public LocalDateTime getDataEmprestimo() { return dataEmprestimo; }
    public LocalDateTime getDataVencimento() { return dataVencimento; }
}
