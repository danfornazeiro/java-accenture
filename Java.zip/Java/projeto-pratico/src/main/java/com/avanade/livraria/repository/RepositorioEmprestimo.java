package com.avanade.livraria.repository;

import java.util.List;
import java.util.Optional;

import com.avanade.livraria.domain.Emprestimo;

public interface RepositorioEmprestimo {
    Emprestimo save(Emprestimo emprestimo);
    Optional<Emprestimo> findById(Long id);
    List<Emprestimo> findAll();
    List<Emprestimo> findEmprestimosAtivos();
    void devolverEmprestimo(Long emprestimoId);
}
