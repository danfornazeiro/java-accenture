package com.avanade.livraria.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

import com.avanade.livraria.domain.Emprestimo;

public class JdbcRepositorioEmprestimo implements RepositorioEmprestimo {
    private final Connection conn;

    public JdbcRepositorioEmprestimo(Connection conn) { this.conn = conn; }

    @Override
    public Emprestimo save(Emprestimo emprestimo) {
        String sql = "INSERT INTO loans(book_id,user_id,loan_date,due_date,return_date) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, emprestimo.getBookId());
            ps.setLong(2, emprestimo.getUserId());
            ps.setTimestamp(3, Timestamp.valueOf(emprestimo.getLoanDate()));
            ps.setTimestamp(4, Timestamp.valueOf(emprestimo.getDueDate()));
            if (emprestimo.getReturnDate() != null) ps.setTimestamp(5, Timestamp.valueOf(emprestimo.getReturnDate())); else ps.setTimestamp(5, null);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) emprestimo.setId(rs.getLong(1));
            }
            return emprestimo;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Emprestimo> findById(Long id) {
        String sql = "SELECT id,book_id,user_id,loan_date,due_date,return_date FROM loans WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Emprestimo l = new Emprestimo(rs.getLong("id"), rs.getLong("book_id"), rs.getLong("user_id"), rs.getTimestamp("loan_date").toLocalDateTime(), rs.getTimestamp("due_date").toLocalDateTime(), rs.getTimestamp("return_date") != null ? rs.getTimestamp("return_date").toLocalDateTime() : null);
                    return Optional.of(l);
                }
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public java.util.List<Emprestimo> findAll() {
        String sql = "SELECT id,book_id,user_id,loan_date,due_date,return_date FROM loans";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                java.util.List<Emprestimo> list = new java.util.ArrayList<>();
                while (rs.next()) {
                    Emprestimo l = new Emprestimo(rs.getLong("id"), rs.getLong("book_id"), rs.getLong("user_id"), rs.getTimestamp("loan_date").toLocalDateTime(), rs.getTimestamp("due_date").toLocalDateTime(), rs.getTimestamp("return_date") != null ? rs.getTimestamp("return_date").toLocalDateTime() : null);
                    list.add(l);
                }
                return list;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public java.util.List<Emprestimo> findEmprestimosAtivos() {
        String sql = "SELECT id,book_id,user_id,loan_date,due_date,return_date FROM loans WHERE return_date IS NULL";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                java.util.List<Emprestimo> list = new java.util.ArrayList<>();
                while (rs.next()) {
                    Emprestimo l = new Emprestimo(rs.getLong("id"), rs.getLong("book_id"), rs.getLong("user_id"), rs.getTimestamp("loan_date").toLocalDateTime(), rs.getTimestamp("due_date").toLocalDateTime(), null);
                    list.add(l);
                }
                return list;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void devolverEmprestimo(Long emprestimoId) {
        String sql = "UPDATE loans SET return_date = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now())); // Simula atraso
            ps.setLong(2, emprestimoId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
