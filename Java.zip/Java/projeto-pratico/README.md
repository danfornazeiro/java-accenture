# Projeto Prático: Biblioteca (JDBC + H2)

Exercício para consolidar OOP, SOLID e Java básico usando apenas JDBC para acesso a banco H2.

## Como rodar:

1. **Build**: `mvn clean package`
2. **Executar aplicação**: `mvn -q exec:java -Dexec.mainClass="com.avanade.livraria.Principal"` (ou executar via IDE)
3. **Rodar testes**: `mvn test`
4. **Executar diretamente no IDE**

## Observações

- **Pacote**: `com.avanade.livraria`
- Aplicação dos princípios SOLID:
  - **S**ingle Responsibility: cada classe tem responsabilidade única (domínio, repositório, serviço).
  - **O**pen/Closed: extensível via herança/strategy futuras.
  - **L**iskov: interfaces permitem substituição (mockito em testes).
  - **I**nterface Segregation: interfaces específicas (`RepositorioLivro`, `RepositorioUsuario`, etc.).
  - **D**ependency Inversion: injeção de dependências via construtores.

## Estrutura de Pacotes

- `com.avanade.livraria.domain` — Entidades: `Livro`, `Usuario`, `Emprestimo`, `TipoUsuario`
- `com.avanade.livraria.repository` — Interfaces + implementações JDBC
- `com.avanade.livraria.service` — Lógica de negócio: `ServicoEmprestimo`
- `com.avanade.livraria.Principal` — Classe de entrada (CLI/Demo)
- `src/test/java/com/avanade/livraria/...` — Testes unitários com H2 em memória

## Diagrama de Contexto

Visão de alto nível do sistema mostrando atores externos e fluxos de dados:

```mermaid
graph LR
    A["Usuário<br/>(Estudante)"]
    B["Professor"]
    C["Bibliotecário"]
    D["[SISTEMA BIBLIOTECA]"]
    E["Banco de Dados<br/>(H2)"]

    A -->|Solicita Empréstimo| D
    B -->|Solicita Empréstimo| D
    C -->|Registra Empréstimo| D
    C -->|Consulta Relatórios| D
    
    D -->|Confirma Empréstimo| A
    D -->|Confirma Empréstimo| B
    D -->|Retorna Dados| C
    
    D -->|Lê/Escreve Dados| E
    E -->|Retorna Dados| D
```

## Diagrama de Classes

```mermaid
classDiagram

class Livro {
	+Long id
	+String title
	+String author
	+String isbn
	+int totalCopies
	+int availableCopies
}

class Usuario {
	+Long id
	+String name
	+String document
	+TipoUsuario userType
}

class Emprestimo {
	+Long id
	+Long bookId
	+Long userId
	+LocalDateTime loanDate
	+LocalDateTime dueDate
	+LocalDateTime returnDate
}

class TipoUsuario {
	ESTUDANTE
	PROFESSOR
}

class RepositorioLivro {
	+save(Livro) : Livro
	+findById(Long) : Optional<Livro>
	+findAll() : List<Livro>
	+update(Livro) : void
}

class RepositorioUsuario {
	+save(Usuario) : Usuario
	+findById(Long) : Optional<Usuario>
}

class RepositorioEmprestimo {
	+save(Emprestimo) : Emprestimo
	+findById(Long) : Optional<Emprestimo>
}

class JdbcRepositorioLivro
class JdbcRepositorioUsuario
class JdbcRepositorioEmprestimo

class ServicoEmprestimo {
	+criarEmprestimo(Long usuarioId, Long livroId) : Emprestimo
}

class Database {
	+init() : void
	+getConnection() : Connection
}

class Principal {
	+main(String[] args) : void
}

RepositorioLivro <|.. JdbcRepositorioLivro
RepositorioUsuario <|.. JdbcRepositorioUsuario
RepositorioEmprestimo <|.. JdbcRepositorioEmprestimo

ServicoEmprestimo --> RepositorioLivro
ServicoEmprestimo --> RepositorioUsuario
ServicoEmprestimo --> RepositorioEmprestimo

Principal --> ServicoEmprestimo
Principal --> Database
Principal --> JdbcRepositorioLivro
Principal --> JdbcRepositorioUsuario
Principal --> JdbcRepositorioEmprestimo

Livro "1" <-- "0..*" Emprestimo : referenciado
Usuario "1" <-- "0..*" Emprestimo : emite
```

## Diagrama Entidade-Relacionamento (ERD)

Estrutura do banco de dados H2:

```mermaid
erDiagram
    LIVRO ||--o{ EMPRESTIMO : tem
    USUARIO ||--o{ EMPRESTIMO : emite

    LIVRO {
        long id PK
        string title
        string author
        string isbn
        int total_copies
        int available_copies
    }

    USUARIO {
        long id PK
        string name
        string document
        string user_type
    }

    EMPRESTIMO {
        long id PK
        long book_id FK
        long user_id FK
        timestamp loan_date
        timestamp due_date
        timestamp return_date
    }
```

## Exercícios Práticos

Implemente os seguintes casos de uso. **Cada um deles deve incluir:**
- Classes de domínio (se necessário)
- Interface + Implementação JDBC do repositório (se necessário)
- Serviço com lógica de negócio
- Testes unitários com H2 em memória

---

### Exercício 1: Devolução de Livro

**Enunciado:**
Crie o fluxo de devolução de livro emprestado. Ao devolver:
- Marque a data de retorno no empréstimo
- Aumente o número de cópias disponíveis do livro
- Gere um registro de multa se a devolução estiver atrasada (após a data de vencimento)

**Requisitos:**
- Criar classe `Multa` com campos: `id`, `emprestimoId`, `valor`, `dataPagamento`
- Adicionar tabela `multas` ao banco
- Criar `RepositorioMulta` com implementação JDBC
- Implementar `ServicoMulta` com método `calcularMulta(dataDevolvida, dataVencimento): BigDecimal`
- Implementar `ServicoEmprestimo.devolverLivro(emprestimoId, dataDevolvida): Emprestimo`
- **Teste**: devolver livro no prazo (sem multa) e após prazo (com multa)

---

### Exercício 2: Listar Empréstimos Ativos

**Enunciado:**
Implemente a funcionalidade de listar todos os empréstimos não finalizados (sem data de retorno).

**Requisitos:**
- Adicionar método `List<Emprestimo> findEmprestimosAtivos()` à interface `RepositorioEmprestimo`
- Implementação JDBC com `WHERE return_date IS NULL`
- Implementar em `ServicoEmprestimo` um método `listarEmprestimosAtivos(): List<EmprestimoDTO>`
- Criar DTO `EmprestimoDTO` com info do livro, usuário e datas
- **Teste**: inserir 3 empréstimos (1 devolvido, 2 ativos) e verificar que retorna apenas os 2

---

### Exercício 3: Usuários com Multas Pendentes

**Enunciado:**
Liste todos os usuários que têm multas não pagas.

**Requisitos:**
- Adicionar método `List<Multa> findMultasNaoPagas()` à `RepositorioMulta`
- Implementar `ServicoMulta.listarUsuariosComMultas(): List<UsuarioMultaDTO>`
- DTO contém: nome usuário, email, valor total das multas, data de geração
- **Teste**: criar 2 usuários, gerar multas para ambos, verificar se retorna corretamente

---

### Exercício 4: Relatório de Empréstimos por Usuário

**Enunciado:**
Gere um relatório mostrando histórico completo de empréstimos de um usuário.

**Requisitos:**
- Adicionar método `List<Emprestimo> findEmprestimosPorUsuario(usuarioId)` em `RepositorioEmprestimo`
- Implementar `ServicoEmprestimo.gerarRelatorioUsuario(usuarioId): RelatorioUsuarioDTO`
- DTO contém: nome usuário, total de empréstimos, livros emprestados, multas acumuladas
- **Teste**: usuário com 3 empréstimos (2 devolvidos, 1 ativo), verificar se retorna corretamente

---

### Exercício 5: Validação de Regras de Empréstimo

**Enunciado:**
Implemente validações rigorosas no ato da criação de empréstimo:
- Usuário não pode ter 3 empréstimos simultâneos (estudante) / 5 (professor)
- Usuário com multas pendentes não pode emprestar
- Livro deve ter pelo menos 1 cópia disponível

**Requisitos:**
- Criar classe de exceção `InvalidarEmprestimoException`
- Adicionar validações em `ServicoEmprestimo.criarEmprestimo()`
- **Teste**: 
  1. Estudante tenta pegar 4º livro (deve falhar)
  2. Professor consegue pegar 5º livro
  3. Usuário com multa tenta emprestar (deve falhar)
  4. Livro sem cópias (deve falhar)

---

### Exercício 6: Renovação de Empréstimo

**Enunciado:**
Permita que um usuário renove um empréstimo ativo (sem devolução) por mais 14/30 dias.

**Requisitos:**
- Adicionar campo `renovacoes` na tabela `loans` (quantidade de vezes renovado)
- Máximo 2 renovações por empréstimo
- Adicionar método `renovarEmprestimo(emprestimoId): Emprestimo` em `ServicoEmprestimo`
- **Teste**: 
  1. Renovar empréstimo 2 vezes (sucesso)
  2. Tentar 3ª renovação (deve falhar)

---

### Exercício 7: Multa Automática por Dia

**Enunciado:**
Implemente cálculo de multa progressiva: R$ 2,00 por dia de atraso (máximo R$ 50,00).

**Requisitos:**
- Método `calcularMultaPorDia(diasAtraso): BigDecimal`
- Se atraso >= 25 dias, multa = R$ 50,00 (máximo)
- Se atraso < 1 dia, multa = R$ 0,00
- **Teste**: atraso de 5 dias (R$ 10,00), atraso de 30 dias (R$ 50,00)

---

### Exercício 8: Buscar Livros por Critério

**Enunciado:**
Implemente busca de livros por título, autor ou ISBN.

**Requisitos:**
- Adicionar métodos no `RepositorioLivro`:
  - `findByTitulo(String titulo): List<Livro>`
  - `findByAutor(String autor): List<Livro>`
  - `findByIsbn(String isbn): Optional<Livro>`
- Implementação JDBC com `LIKE` para título/autor
- **Teste**: inserir 3 livros, buscar por título parcial (ex: "Clean"), verificar retorno

---

### Exercício 9: Relatório de Livros Mais Emprestados

**Enunciado:**
Liste os 5 livros mais emprestados (com maior número de empréstimos).

**Requisitos:**
- Adicionar método em `RepositorioEmprestimo`: `findTop5LivrosMaisEmprestados(): List<LivroEmprestimoDTO>`
- DTO contém: `livroId`, `titulo`, `quantidadeEmprestimos`
- **Teste**: criar 5 livros com diferentes números de empréstimos, verificar ordenação

---

### Exercício 10: Integração Completa (Desafio)

**Enunciado:**
Crie um cenário de teste que exercita todo o fluxo:
1. Criar 3 livros, 2 usuários
2. Usuário 1 empresta livro 1
3. Usuário 2 empresta livros 2 e 3
4. Usuário 2 devolve livro 2 (com atraso, gerando multa)
5. Listar empréstimos ativos
6. Listar usuários com multas
7. Gerar relatório de usuário 2

**Requisitos:**
- Criar teste integrado `TestFluxoCompleto.java`
- Usar `@BeforeEach` para seed comum
- Validar todos os estados finais (livros, usuários, empréstimos, multas)

---

## Dicas para Implementação

1. **Sempre use interfaces** — nunca injete implementações JDBC diretamente
2. **Escreva testes ANTES** da implementação (TDD)
3. **Use transações JDBC** para operações múltiplas
4. **Validações devem estar no serviço**, não no repositório
5. **DTOs** para transferência de dados complexos (especialmente relatórios)
6. **Exceções customizadas** para erros de negócio
7. **Índices no banco** para melhorar performance em buscas

