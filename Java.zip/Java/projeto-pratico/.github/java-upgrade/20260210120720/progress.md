# Upgrade Progress

  ### ✅ Generate Upgrade Plan
  - [[View Log]](logs\1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Install JDK 11
  </details>

  ### ✅ Confirm Upgrade Plan
  - [[View Log]](logs\2.confirmPlan.log)

  ### ✅ Setup Development Environment
  - [[View Log]](logs\3.setupEnvironment.log)

  ### ✅ PreCheck
  - [[View Log]](logs\4.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Precheck - Build project
    - [[View Log]](logs\4.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  
    ### ✅ Precheck - Validate CVEs
    - [[View Log]](logs\4.2.precheck-validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### CVE issues
    </details>
  
    ### ❗ Precheck - Run tests
    - [[View Log]](logs\4.3.precheck-runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Errors
    Failed to run tests with errors: [ERROR] Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.13.0:compile (default-compile) on project library: Fatal error compiling: error: invalid target release: 21 -\> [Help 1] [ERROR]  [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. [ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]  [ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
      ```
      Error: Failed to run tests with errors:
      [ERROR] Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.13.0:compile (default-compile) on project library: Fatal error compiling: error: invalid target release: 21 -\> [Help 1]
      [ERROR] 
      [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch.
      [ERROR] Re-run Maven using the -X switch to enable full debug logging.
      [ERROR] 
      [ERROR] For more information about the errors and possible solutions, please read the following articles:
      [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
      	at DGe.test (c:\Users\nelson.fornazeiro\.vscode\extensions\vscjava.vscode-java-upgrade-1.12.1\dist\extension.js:761:2634)
      	at async W9n (c:\Users\nelson.fornazeiro\.vscode\extensions\vscjava.vscode-java-upgrade-1.12.1\dist\extension.js:1053:224)
      	at async sT.doInvoke (c:\Users\nelson.fornazeiro\.vscode\extensions\vscjava.vscode-java-upgrade-1.12.1\dist\extension.js:1047:1328)
      	at async sT.invoke (c:\Users\nelson.fornazeiro\.vscode\extensions\vscjava.vscode-java-upgrade-1.12.1\dist\extension.js:822:10012)
      	at async YMe.invoke (c:\Users\nelson.fornazeiro\.vscode\extensions\vscjava.vscode-java-upgrade-1.12.1\dist\extension.js:1473:172)
      	at async bQ.$invokeTool (file:///c:/Users/nelson.fornazeiro/AppData/Local/Programs/Microsoft%20VS%20Code/bdd88df003/resources/app/out/vs/workbench/api/node/extensionHostProcess.js:195:3384)
      ```
    </details>
  </details>

  ### ⏳ Upgrade project to use `Java 21` ...Running
  
  
  - ###
    ### ⏳ Upgrade using Agent ...Running