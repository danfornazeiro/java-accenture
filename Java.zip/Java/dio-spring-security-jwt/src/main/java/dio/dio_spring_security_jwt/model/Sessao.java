package dio.dio_spring_security_jwt.model;

public class Sessao {
    private String token;
    private String sessao;

    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }

    public String getSessao() {
        return sessao;
    }

    public void setSessao(String sessao) {
        this.sessao = sessao;
    }

    public void setLogin(String username) {
        this.sessao = username;
    }
}
