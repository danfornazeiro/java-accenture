package dio.spring_data_jpa;

import dio.spring_data_jpa.model.User;
import dio.spring_data_jpa.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class StartApp implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;
    @Override
    public void run(String... args) throws Exception {
        User user1 = new User();
        user1.setName("Daniel Fornazeiro");
        user1.setPassword("dio1234");
        user1.setUsername("Daniel");

        userRepository.save(user1);

        for (User user : userRepository.findAll()) {
            System.out.println(user);
        }
    }
}
