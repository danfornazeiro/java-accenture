
plugins {
    id("java")
    id("application")
}



group = "br.com.dio"
version = "1.0-SNAPSHOT"
val mapstructVersion = "1.5.5.Final"
val lombokVersion = "1.18.30"
val lombokMapstructBindingVersion = "0.2.0"

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.mapstruct:mapstruct:${mapstructVersion}")
    implementation("org.projectlombok:lombok-mapstruct-binding:${lombokMapstructBindingVersion}")

    compileOnly("org.projectlombok:lombok:${lombokVersion}")

    annotationProcessor("org.mapstruct:mapstruct-processor:${mapstructVersion}")
    annotationProcessor("org.projectlombok:lombok-mapstruct-binding:${lombokMapstructBindingVersion}")
    annotationProcessor("org.projectlombok:lombok:${lombokVersion}")
}




