import br.com.dio.dao.UserDAO;
import br.com.dio.execption.EmptyStorageException;
import br.com.dio.execption.UserNotFoundException;
import br.com.dio.model.UserModel;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    private final static UserDAO userDao = new UserDAO();
    private final static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        while(true){
            System.out.println("Bem vindo ao cadastro de usuários!");
            System.out.println("1 - Cadastrar");
            System.out.println("2 - Atualizar");
            System.out.println("3 - Deletar");
            System.out.println("4 - Buscar por ID");
            System.out.println("5 - Listar todos");
            System.out.println("6 - Sair");

            var option = scanner.nextInt();

            var selectedOption = MenuOption.values()[option - 1];

            switch (selectedOption) {
                case SAVE -> {
                    var userModel = requestUserInfo();
                    var savedUser = userDao.saveModels(userModel);
                    System.out.println("Usuário cadastrado com sucesso! ID: " + savedUser.getId());
                }
                case UPDATE -> {
                    try {
                        System.out.println("Digite o ID do usuário a ser atualizado: ");
                        var id = scanner.nextLong();
                        var userModel = requestUserInfo();
                        userModel.setId(id);
                        var updatedUser = userDao.updateModel(userModel);
                        System.out.println("Usuário atualizado com sucesso! ID: " + updatedUser.getId());
                    } catch (EmptyStorageException | UserNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                }
                case DELETE -> {
                    try {
                        var user = requestById();
                        userDao.deleteModel(user);
                        System.out.println("Usuário excluido com sucesso: ");
                    } catch (EmptyStorageException | UserNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                }
                case FIND_BY_ID -> {
                    try {
                        var user = requestById();
                        System.out.println(user.getName());
                    } catch (EmptyStorageException | UserNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                }
                case FIND_ALL -> {
                    try {
                        var users = userDao.findAll();
                            users.forEach(user -> System.out.println("ID: " + user.getId() + ", Nome: " + user.getName()));
                    } catch (EmptyStorageException | UserNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                }
                case EXIT -> System.exit(0);
            }
        }
    }

    private static UserModel requestUserInfo() {
        System.out.println("Digite o nome do usuário: ");
        var name = scanner.next();
        System.out.println("Digite o email: do usuário: ");
        var email = scanner.next();
        System.out.println("Digite a data do nascimento [dd/MM/yyyy]: ");
        var birthDate = scanner.next();
        var formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        var birthDateFormatted = LocalDate.parse(birthDate, formatter).atStartOfDay().atOffset(ZoneOffset.UTC);

        return new UserModel(
                0,
                name,
                email,
                birthDateFormatted
        );
    }

    private static UserModel requestById() {
        System.out.println("Digite o ID do usuário a ser buscado: ");
        var userId = scanner.nextLong();
        try
        {
            var user = userDao.findById(userId);
            return user;

        } catch (EmptyStorageException | UserNotFoundException e) {
            System.out.println(e.getMessage());
            return requestById();
        }


    }

}