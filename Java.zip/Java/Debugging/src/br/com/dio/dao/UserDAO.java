package br.com.dio.dao;

import br.com.dio.execption.EmptyStorageException;
import br.com.dio.execption.UserNotFoundException;
import br.com.dio.model.UserModel;

import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private long nextId = 1L;
    private final List<UserModel> models = new ArrayList<>();

    public UserModel saveModels(final UserModel model) {
        model.setId(nextId++);
        models.add(model);
        return model;
    }

    public UserModel updateModel(final UserModel model){
        findById(model.getId());
        var toUpdate = findById(model.getId());
        models.remove(toUpdate);
        models.add(model);
        return model;
    }

    public void deleteModel(final UserModel model){
        verifyStorage();
        var toDelete = findById(model.getId());
        models.remove(toDelete);
    }

    public UserModel findById(final long id) {
        try {
            verifyStorage();
            return models.stream().
                    filter(model -> model.getId() == id)
                    .findFirst().orElse(new UserModel());
                    //.orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));
        } catch (EmptyStorageException e) {
            new EmptyStorageException(e.getMessage());
            //e.printStackTrace();
            return new UserModel();
        }
    }

    public List<UserModel> findAll() {
        try {
            verifyStorage();
            return models;
        } catch (EmptyStorageException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    private void verifyStorage(){
        if(models.isEmpty()){
            throw new EmptyStorageException("O armazenamento está vazio.");
        }
    }
}
