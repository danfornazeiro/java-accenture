package dio.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeirosPassosApplication {

	public static void main(String[] args) {

		SpringApplication.run(PrimeirosPassosApplication.class, args);

		/*jeito errado
		Calculadora calculadora = new Calculadora();
		System.out.println("O resultado da soma é: " + calculadora.somar(5, 10));*/

	}

}
