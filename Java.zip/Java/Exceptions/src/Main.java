import java.io.FileNotFoundException;
import java.io.FileOutputStream;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        test2();
    }

    private static void test() throws FileNotFoundException {
        var stream = new FileOutputStream("output.txt");
    }

    private static void test2() throws RuntimeException {
        System.out.println((10/0));
    }
}