public class Info {
    /*Tipos primitivos

    int i;
    long l;
    float f;
    double d;
    char c;
    byte b;
    boolean bool;
    short s;

    Tipos por referência
    String str;
    Object obj;

    Tipos wrapper (Objetos que encapsulam os tipos primitivos)
    Integer integer;
    Long longg;
    Float floatt;
    Double doublee;
    Character chara;
    Byte bytee;
    Boolean booleann;
    Short shortt;*/
}
