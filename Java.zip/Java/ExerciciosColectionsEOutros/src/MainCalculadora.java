import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class MainCalculadora {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println("Entre com os números separados por vírgula: ");
            String numeros = input.nextLine();
            System.out.println("Entre com a operação desejada (soma[+] ou subtração[-] ou [s] para sair): ");
            String operacao = input.nextLine();

            var numerosDigitados = numeros.split(",");

            switch(operacao) {
                case "+":
                    int resultadoSoma = soma(numerosDigitados);
                    System.out.println("O resultado da soma é: " + resultadoSoma);
                    break;
                case "-":
                    int resultadoSubtracao = subtracao(numerosDigitados);
                    System.out.println("O resultado da subtração é: " + resultadoSubtracao);
                    break;
                case "s":
                    System.out.println("Encerrando a calculadora. Até mais!");
                    return;
                default:
                    System.out.println("Operação inválida!");
            }
        }
    }


    private static int soma(String[] numerous){
        int resultado = 0;
        for (int i = 0; i < numerous.length; i++) {
            resultado += Integer.parseInt(numerous[i]);
        }

        return resultado;
    }

    private static int subtracao(String[] numerous){
        int resultado = 0;
        for (int i = 0; i < numerous.length; i++) {
            if (resultado == 0) {
                resultado = Integer.parseInt(numerous[i]);
                continue;
            }

            resultado -= Integer.parseInt(numerous[i]);
        }

        return resultado;
    }
}