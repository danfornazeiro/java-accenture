package br.com.dio.springpropertyvalue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPropertyValueApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringPropertyValueApplication.class, args);
    }


}
