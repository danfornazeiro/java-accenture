package br.com.dio.springpropertyvalue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class SistemaMensagem implements CommandLineRunner {
    @Autowired
    private Remetente remetente;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Mensagem enviada por: " +
                remetente.getNome() + "\n" +
                remetente.getEmail() + "\n" + "Telefone contato: " +
                remetente.getTelefones());
        System.out.println("Seu cadastro foi Aprovado");
    }
}
