package br.com.dio.springpropertyvalue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPropertyValueApplicationTests {

    @Test
    void contextLoads() {
    }

}
