import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class MainIntro {
    public static void main(String[] args) {
        /*
        equivale a vat test = new Integer[1];
        */
        var value1 = Stream.generate(() -> new Random().nextInt()).limit(5).toArray(Integer[]::new);

        for (var value : value1) {
            System.out.println(value);
        }

        System.out.println("-----");

        var value2 = IntStream.generate(() -> new Random().nextInt()).limit(5).toArray();

        for (var value : value2) {
            System.out.println(value);
        }

        System.out.println("--stream of--");
        var value = Stream.of("Maria", "João", "Paulo").filter(name -> name.endsWith("o")).toList();
        System.out.println(value);

        System.out.println("--peek--"); //intercepta o valor no meio do stream para auxiliar no debug
        var value0 = Stream.of("Maria", "João", "Paulo")
                .peek(System.out::println).filter(name -> name.endsWith("o")).toList();
        System.out.println(value);

        System.out.println("--peek--"); //posso armazenar os valores interceptados em uma lista para debug
        List<String> debugValues = new ArrayList<>();
        var values = Stream.of("Maria", "João", "Paulo")
                .peek(debugValues::add).filter(name -> name.endsWith("o")).toList();
        System.out.println(debugValues);

        System.out.println("--convert list to stream--"); //convertendo uma lista em stream
        value = List.of("Maria", "João", "Paulo")
                .stream()
                .peek(System.out::println).filter(name -> name.endsWith("o")).toList();
        System.out.println(value);

        System.out.println("--stream of anyMatch--");
        var anyValue = Stream.of("Maria", "João", "Paulo").anyMatch(n -> n.contains("z"));
        System.out.println(anyValue);

        System.out.println("--stream of noneMatch--");
        anyValue = Stream.of("Maria", "João", "Paulo").noneMatch(n -> n.contains("z"));
        System.out.println(anyValue);

        System.out.println("--stream of parallel--");
        anyValue = Stream.of("Maria", "João", "Paulo").parallel().noneMatch(n -> n.contains("z"));
        System.out.println(anyValue);

        System.out.println("--stream of reduce--"); //join do .net
        var anyValues = Stream.of("Maria", "João", "Paulo").reduce("", (s1, s2) -> s1 + "; " + s2);
        System.out.println(anyValues);

        System.out.println("--IntStream media--");
        var media = IntStream.of(1,2,3,4,5).average();
        System.out.println(media);

        System.out.println("--IntStream media--");
        var soma = IntStream.of(1,2,3,4,5).sum();
        System.out.println(soma);

        System.out.println("--Stream distinct--");
        var distinct = Stream.of(1,2,3,4,5,6,3,2).distinct().toList();
        System.out.println(distinct);

        System.out.println("--Stream map--");
        var map = Stream.of(1,2,3,4,5,6,3,2).map(n -> n % 2 == 0).toList();
        System.out.println(map);

        var list1 = List.of(3,6,9,12);
        var list2 = List.of(1,2,3,4,5,6,7,8,9,10,11,12);

        System.out.println("--------");
        var list = list2.stream()
                .parallel()
                .filter(list1::contains)
                .peek(n -> System.out.printf("Filter %s \n", n))
                .map(n -> list1.stream().reduce(n, (a, b) -> a - b))
                .peek(n -> System.out.printf("Map %s \n", n))
                .collect(Collectors.toSet());
        System.out.println(list);
    }
}