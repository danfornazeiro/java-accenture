import domain.*;

import java.util.ArrayList;
import java.util.List;

public class MainExplore {
    public static void main(String[] args) {
        /*EXPLORANDO API DE STREAMS*/

        List<User> users = new ArrayList<>(generateUsers());
        users.forEach(System.out::println);

        System.out.println("--------------------------------------------------");
        var values = users.stream().filter(u -> u.contacts().size() >= 2).toList();
        values.forEach(System.out::println);

        System.out.println("--------------------------------------------------");
        var values1 = users.stream().filter(u -> u.contacts() == null || u.contacts().isEmpty()).toList();
        values1.forEach(System.out::println);

        System.out.println("--------------------------------------------------");
        var values2 = users.stream()
                .flatMap(u -> u.contacts().stream())
                .filter(c -> c.type() == ContactType.MOBILE_PHONE)
                .sorted((c1, c2) -> c1.description().compareTo(c2.description())).toList();
        values2.forEach(System.out::println);
    }

    private static List<User> generateUsers() {
        var contacts1 = List.of(
                new Contact("(11)96123-4567", ContactType.PHONE),
                new Contact("zedascouves@email.com", ContactType.EMAIL)

        );

        var contacts2 = List.of(
                new Contact("(11)67589-1231", ContactType.PHONE)
        );

        var contacts3 = List.of(
                new Contact("(99)8765-4321", ContactType.PHONE),
                new Contact("(99)8765-4321", ContactType.MOBILE_PHONE),
                new Contact("ciclano@teste.com", ContactType.EMAIL)
        );

        var contacts4 = List.of(
                new Contact("(85)96541-3214", ContactType.PHONE),
                new Contact("(85)96133-5847", ContactType.PHONE)
        );

        var contacts5 = List.of(
                new Contact("(13)96582-5874", ContactType.PHONE),
                new Contact("(13)96582-5874", ContactType.MOBILE_PHONE),
                new Contact("praia@teste.com", ContactType.EMAIL)
        );

        var user1 = new User("Alice", 30, Sex.FEMALE, contacts1);
        var user2 = new User("Bob", 25, Sex.MALE, contacts2);
        var user3 = new User("Charlie", 35, Sex.MALE, contacts3);
        var user4 = new User("Diana", 28, Sex.FEMALE, new ArrayList<>());
        var user5 = new User("Eve", 22, Sex.FEMALE, contacts5);

        return List.of(user1, user2, user3, user4, user5);
    }
}
