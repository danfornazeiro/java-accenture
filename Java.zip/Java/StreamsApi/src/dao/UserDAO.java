package dao;
import domain.UserDomain;

public class UserDAO extends GenericDAO<Integer, UserDomain> {
    
}
