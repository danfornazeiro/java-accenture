package dao;

import domain.ClientDomain;

public class ClientDAO extends GenericDAO<Integer, ClientDomain>{
}
