package dao;

import domain.GenericDomain;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public abstract class GenericDAO<ID, T extends GenericDomain<ID>> {
    private final List<T> db = new ArrayList<>();

    private T save(T entity) {
        db.add(entity);
        return entity;
    }

    public boolean save(int batch, T... entities) {
        System.out.printf("Saving batch of (%d) entities\n", batch);
        return db.addAll(Arrays.stream(entities).toList());
    }

    public T update(ID id, T entity) {
        var stored = find(d -> d.getId().equals(id))
                .orElseThrow();

        db.remove(stored);

        return save(entity);
    }

    public void delete(T entity) {
        db.remove(entity);
    }

    public Optional<T> find(Predicate<T> filterCallback) {
        return db.stream()
                .filter(filterCallback)
                .findFirst();
    }

    public List<T> findAll() {
        return new ArrayList<>(db);
    }

    public int count() {
        return db.size();
    }
}
