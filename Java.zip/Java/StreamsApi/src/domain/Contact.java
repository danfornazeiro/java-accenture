package domain;

public record Contact(String description, ContactType type) {

}
