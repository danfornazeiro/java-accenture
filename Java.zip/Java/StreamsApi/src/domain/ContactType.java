package domain;

public enum ContactType
{
    EMAIL,
    PHONE,
    MOBILE_PHONE
}
