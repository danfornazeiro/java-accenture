package domain;

import java.util.Objects;

public class ClientDomain implements GenericDomain<Integer>{
    private Integer id;
    private String name;
    private int age;

    public ClientDomain(final int id, final String name, final Integer age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public ClientDomain() {}

    public String getName() {
        return name;
    }

    @Override
    public Integer getId() {
        return id;
    }

    @Override
    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof ClientDomain that)) return false;
        return Objects.equals(id, that.id) && Objects.equals(name, that.name) && Objects.equals(age, that.age);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, age);
    }

    @Override
    public String toString() {
        return "ClientDomain{" +
                "id='" + this.getId() + '\'' +
                "name='" + name + '\'' +
                ", age='" + age + '\'' +
                '}';
    }
}
