import dao.ClientDAO;
import dao.GenericDAO;
import dao.UserDAO;
import domain.ClientDomain;
import domain.UserDomain;

public class Main {
    private static final GenericDAO<Integer, UserDomain> userDAO = new UserDAO();
    private static final GenericDAO<Integer, ClientDomain> clientDAO = new ClientDAO();

    public static void main(String[] args) {
        var user = new UserDomain(1,"John", 25);
        var user2 = new UserDomain(2,"Mary", 28);

        System.out.println("=============USERDAO=============");
        System.out.println(userDAO.count());
        System.out.println(userDAO.save(1, user));
        System.out.println(userDAO.save(1, user2));
        System.out.println(userDAO.count());
        System.out.println(userDAO.find(d -> d.getId().equals(1)).orElse(null));
        System.out.println(userDAO.findAll());
        userDAO.delete(user);
        System.out.println(userDAO.findAll());
        System.out.println(userDAO.find(d -> d.getId().equals(2)).orElse(null));
        System.out.println(userDAO.count());
        System.out.println("=============USERDAO FIM=============");

        var client = new ClientDomain(1,"John", 25);
        var client2 = new ClientDomain(2,"Mary", 28);

        System.out.println("=============CLIENTDAO=============");
        System.out.println(clientDAO.count());
        System.out.println(clientDAO.save(1, client));
        System.out.println(clientDAO.save(1, client2));
        System.out.println(clientDAO.count());
        System.out.println(clientDAO.find(d -> d.getId().equals(1)).orElse(null));
        System.out.println(clientDAO.findAll());
        clientDAO.delete(client);
        System.out.println(clientDAO.findAll());
        System.out.println(clientDAO.find(d -> d.getId().equals(2)).orElse(null));
        System.out.println(clientDAO.count());
        System.out.println("=============CLIENTDAO FIM=============");
    }
}
