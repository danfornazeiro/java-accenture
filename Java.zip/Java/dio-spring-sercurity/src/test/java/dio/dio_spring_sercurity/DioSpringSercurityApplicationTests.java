package dio.dio_spring_sercurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DioSpringSercurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
