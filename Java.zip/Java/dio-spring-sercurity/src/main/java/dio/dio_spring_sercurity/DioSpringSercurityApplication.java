package dio.dio_spring_sercurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DioSpringSercurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(DioSpringSercurityApplication.class, args);
	}

}
