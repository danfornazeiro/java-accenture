package br.com.dio.springscopessingletonprototype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringScopesSingletonPrototypeApplicationTests {

    @Test
    void contextLoads() {
    }

}
