package dio.web.api.repository;

import dio.web.api.handler.BusinessException;
import dio.web.api.model.Usuario;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class UsuarioRepository {
    public void save(Usuario usuario) {
        if (usuario.getLogin() == null)
            throw new BusinessException("O campo login é obrigatório");

        if (usuario.getId() == null) {
            System.out.println("SAVE");
        } else {
            System.out.println("UPDATE");
        }

        System.out.println(usuario);
    }

    public void deleteById(int id){
        System.out.println(String.format("DELETE/id - Recebendo o id: %s para excluir o usuario.", id));
        System.out.println(id);
    }

    public Usuario findById(int id){
        System.out.println(String.format("Recebendo o id: %s para buscar.", id));
        return new Usuario("Nelson", "1234");
    }

    public Usuario findByUserName(String userName){
        System.out.println(String.format("FIND BY NAME - Recebendo os usuarios para buscar: %s", userName));
        return new Usuario("Nelson", "1234");
    }

    public List<Usuario> findAll(){
        System.out.println("FIND ALL - Listando todos os usuarios");
        List<Usuario> usuarios = new ArrayList<>();
        usuarios.add(new Usuario("Nelson", "1234"));
        usuarios.add(new Usuario("Regina", "5678"));
        return usuarios;
    }

    public void update(Usuario usuario) {
        if (usuario.getId() == null) {
            System.out.println("SAVE");
        } else {
            System.out.println("UPDATE");
        }

        System.out.println(usuario);
    }

}
