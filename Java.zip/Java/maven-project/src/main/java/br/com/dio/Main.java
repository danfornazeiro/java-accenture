package br.com.dio;

import br.com.dio.dto.UserDTO;
import br.com.dio.mapper.UserMapper;
import br.com.dio.model.UserModel;
import org.mapstruct.factory.Mappers;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    private final static UserMapper mapper = Mappers.getMapper(UserMapper.class);

    public static void main(String[] args) {
        var usrModel = new UserModel();
        usrModel.setUsername("admin");
        usrModel.setCode(2);
        usrModel.setBirthdate(java.time.LocalDate.of(1990, 1, 1));
        System.out.println(mapper.userModelToUserDTO(usrModel));

        var usrDto = new UserDTO();
        usrDto.setId(1);
        usrDto.setName("John Doe");
        usrDto.setBirthDate(java.time.LocalDate.of(1990, 1, 1));
        System.out.println(mapper.userDTOToUserModel(usrDto));

    }
}