package br.com.dio.dto;

import lombok.Data;

import java.time.LocalDate;

/*@Data ajuda na criação de getters, setters, etc
dar uma olhada na UserDTO que ele gerou dentro da pasta target*/
@Data
public class UserDTO {
    private int id;
    private String name;
    private LocalDate birthDate;
}
