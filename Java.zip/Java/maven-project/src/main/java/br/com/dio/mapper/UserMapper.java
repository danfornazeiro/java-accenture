package br.com.dio.mapper;

import br.com.dio.dto.UserDTO;
import br.com.dio.model.UserModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface UserMapper {
    @Mapping(target = "code", source = "id")
    @Mapping(target = "username", source = "name")
    @Mapping(target = "birthdate", source = "birthDate")
    UserModel userDTOToUserModel(final UserDTO userDTO);

    @Mapping(target = "id", source = "code")
    @Mapping(target = "name", source = "username")
    @Mapping(target = "birthDate", source = "birthdate")
    UserDTO userModelToUserDTO(final UserModel userModel);
}
